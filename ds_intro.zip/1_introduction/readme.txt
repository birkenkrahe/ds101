Marcus Birkenkrahe


Table of Contents
_________________

1. Unpack the ZIP file
2. Open the HTML file
3. Read the PDF file
4. Trouble?
5. Copyright


1 Unpack the ZIP file
=====================

  Either unpack `ds_intro.zip' using your explorer (where you access
  your files), or type
  ,----
  | unzip ds_intro.zip
  `----
  The unpacking should generate a folder named `1_introduction'. Enter
  the folder. Inside you find three files to look at and another folder:
   File                 Description                                  
  -------------------------------------------------------------------
   `introduction.html'  HTML file for active viewing in a browser    
   `introduction.pdf'   PDF file for reading/printing(without links) 
   `introduction.org'   Emacs Org-mode file                          
   `img'                Folder with images                           
  There's nothing to do for you with the `.org' file or with the `img'
  folder unless you want to change it.


2 Open the HTML file
====================

  Either click on the file in your explorer, which should open a browser
  window, or type
  ,----
  | [browser] introduction.html
  `----
  where `browser' is `firefox' or `google-chrome' or any other browser.


3 Read the PDF file
===================

  Open the PDF file `introduction.pdf' and read it. The PDF does not
  have active links embedded in the text, but it does have all
  images. If you're after the links, go to the HTML file.


4 Trouble?
==========

  If you encounter any trouble, contact me at
  `birkenkrahe@hwr-berlin.de'.


5 Copyright
===========

  GNU General Public License v3.0 -
  <https://www.gnu.org/licenses/gpl-3.0.en.html>
